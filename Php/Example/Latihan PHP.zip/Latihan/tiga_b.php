<HTML>
<HEAD>
<TITLE>Latihan Menampilkan Variabel</TITLE>
</HEAD>
<BODY>

<?php
  $umur = $_POST["umur"];
  echo "Umur anda = <B>$umur</B>");
?>

</BODY>
</HTML>