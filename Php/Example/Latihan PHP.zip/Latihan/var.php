<html>
<head>

<title>variabel </title>
</head>
<body>

<?php

$thn_lhr = 2000;
$thn_skr = 2013;
$umur = $thn_skr - $thn_lhr;

echo "<h2> USIA ANDA </h2>";
echo "<hr>";
echo "Anda Lahir Tahun = $thn_lhr <br>" ;
echo "Sekarang tahun = $thn_skr <br>" ;   
echo "Maka usia Anda Saat Ini  = $umur tahun" ;   

?>

</body>
</html>