<html>
<body>
<?php
$d=date("D");
if ($d=="Sat")
  {
  echo "Hello!<br />"; 
  echo "Have a nice weekend!<br />";
  echo "See you on Monday!";
  }
?>
</body>
</html>
