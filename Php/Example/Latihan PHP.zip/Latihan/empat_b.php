<HTML>
<HEAD>
<TITLE>Latihan Menampilkan Variabel</TITLE>
</HEAD>
<BODY>

<?php
  $nama = $_POST["nama"];
  $skrng = $_POST["skrng"];
  $tahun = $_POST["tahun"];
  $umur = $skrng - $tahun ;
  
  echo "Nama anda = <B>$nama</B> <br>";
  echo "Umur anda = <B>$umur</B> tahun";
?>

</BODY>
</HTML>