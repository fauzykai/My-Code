
	

<?php

$angka1 = 1500;
$angka2 = 500;
$jumlah = $angka1 + $angka2;

echo "<h2> PENJUMLAHAN </h2>";
echo "<hr>";
echo "Berapa hasil penjumlahan $angka1 dan $angka2 ? </br>" ;  
echo "Jawaban  = $jumlah " ;   

?>
	 
