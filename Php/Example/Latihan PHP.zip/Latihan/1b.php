<HTML>
<HEAD>
<TITLE>Latihan Menampilkan Variabel</TITLE>
</HEAD>
<BODY>

<?php
  $umur = $_POST["umur"];
  print("Umur anda = <B>$umur</B>");
?>

</BODY>
</HTML>