<HTML>
<HEAD>
<TITLE>Latihan Pemasukan Data</TITLE>
</HEAD>

<FORM ACTION="empat_b.php" METHOD="POST">
  <p><strong>MENGHITUNG  USIA ANDA </strong></p>
  <p>Nama Anda : 
    <INPUT NAME="nama" TYPE="TEXT" id="nama">
    <br>
    Lahir Tahun : 
    <label>
     <input name="tahun" type="text" id="tahun" size="4" maxlength="4">
    </label>
    <br>
    Tahun Sekarang : 
    <label>
    <input name="skrng" type="text" id="skrng" size="4" maxlength="4">
    </label>
    <BR>
    <BR>
    <INPUT TYPE="SUBMIT" Value="Kirim">
  </p>
</FORM>

</BODY>
</HTML>
