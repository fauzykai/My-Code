<html>
<head>
	<title> First </title>
<head>
<body>

<?php
//contoh STATEMENT
echo "<h1>hello Guys � ! </h1>";
echo "Saya dari Script PHP";
echo "<h2>Ini adalah contoh dari penulisan Script PHP</h2>";
?>

</body>
</html>