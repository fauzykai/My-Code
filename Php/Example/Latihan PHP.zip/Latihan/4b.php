<HTML>
<HEAD>
<TITLE> Hasil Latihan ketiga </TITLE>
</HEAD>
<BODY>
<?php
$nama = $_POST["nama"];
$pesan = $_POST["pesan"];
echo "<B>Data yang Anda masukkan :</B> <BR>";
echo "Nama Anda : $nama <BR>";
echo "Pesan Anda : $pesan";
?>
</BODY>
</HTML> 
