<HTML>
<HEAD>
<TITLE>Latihan Pemasukan Data</TITLE>
</HEAD>

<FORM ACTION="simpan.php" METHOD="POST">
Silakan Masukkan umur Anda:<BR>
<INPUT TYPE="TEXT" NAME="umur"><BR>
Penulisan umur, contoh : 20 tahun dst.<BR>
<INPUT TYPE="SUBMIT" Value="Kirim">
</FORM>

</BODY>
</HTML>
