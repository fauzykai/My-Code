<html>
<head>

<title>variabel </title>
</head>
<body>

<?php

$thn_lhr = 2000;
$thn_skr = 2011;
$umur = $thn_skr - $thn_lhr;

echo "<h2> USIA ANDA </h2>";
echo "<hr>";
echo "Anda Lahir Tahun = $thn_lhr <br>" ;  
echo "Usia Anda Saat Ini  = $umur " ;   

?>

</body>
</html>