<html>
<head>
<title> Perulangan </title>
</head>

<body>

<?php
/* contoh FOR 1 */
for ($i = 90; $i <= 100; $i++) {
echo " $i " ;

}

?>
<hr>



<?php
/* contoh FOR 2 */
for ($i = 5; ; $i++) {
if ($i > 10) {
break;
}
echo "$i ";
}

?>

<hr>


<?php
/* contoh WHILE 1 */
$i = 1;
while ($i <= 10) {
echo $i++ ;
echo " " ;
}
echo "<br>";
?>


<hr>
<?
/* contoh WHILE 2 */
$bil =0;
while ($bil<=100) 
{
	echo "$bil";
	$bil=$bil+5;
	echo " " ;
	
	
} 
?>


<hr>

<?php
/* contoh WHILE  */
$i = 1;
while ($i <= 10) {
$i++; 
echo "$i";


}
?>

<hr>


<?php
/* contoh WHILE  */
$i = 1;
while ($i <= 6) {
echo "<h$i>Heading $i</h$i>";
$i++;
}
?>

<hr size=5 color=red>

<?php
/* contoh DO..WHILE  */
$i = 1;
do {
echo "$i ";
$i+=2;
} while ($i <= 20);
?>




</body>
</html>