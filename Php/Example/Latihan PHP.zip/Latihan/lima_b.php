<HTML>
<HEAD>
<TITLE>Latihan Menampilkan Variabel</TITLE>
</HEAD>
<BODY>

<?php
  $barang = $_POST["barang"];
  $harga = $_POST["harga"];
  $diskon = $_POST["diskon"];
  $qty = $_POST["qty"];
  $jumlah= $harga * $qty ;
  $potong = $diskon * $jumlah;
  $bayar = $jumlah - $potong ;
  echo "$diskon <br>";
  echo "Anda Memesan  = <B>$barang</B> <br>";
  echo "sebanyak = <B>$qty</B> Bungkus <br>";
  echo "dengan harga satuan = Rp. <B>$harga</B> <br>";
  echo "Nilai yang harus anda bayar sebelum diskon  = Rp. <B>$jumlah</B> <br>";
  echo "dikurangi diskon sebesar = Rp.  <B>$potong</B> <br>";
  echo "Yang harus anda bayar setelah dipotong diskon adalah = Rp.  <B>$bayar</B>";
?>

</BODY>
</HTML>