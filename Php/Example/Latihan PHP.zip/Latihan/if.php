<html>
<head>
<title> IF </title>
</head>
<body>


<?php
// KONDISI IF
$nilai = 80;
if ($nilai >= 60) {
echo "Nilai Anda $nilai, Anda LULUS";
}
?>

<hr>
<?php
// KONDISI IF
$cuaca = "hujan";
if ($cuaca == "hujan") {
echo "Cuaca hari ini  $cuaca, Ayo tidur lagi !!!";
}
?>



<hr>
<?php
//KONDISI IF..ELSE
$nilai = 50;
if ($nilai >= 60) {
echo "Nilai Anda $nilai, Anda LULUS";
} else {
echo "Nilai Anda $nilai, Anda GAGAL";
}
?>
<hr>

<?php
//KONDISI IF..ELSE
$user = "Akbar";
$pass = "asdf";
if ($user == "Akbar" && $pass == "asdf") {
echo "Login Berhasil";
} else {
echo "Login Gagal";
}
?>

<hr>

<?php
// KONDISI IF..ELSE
$cuaca = "cerah";
if ($cuaca == "hujan") {
echo "Cuaca hari ini  $cuaca, Ayo tidur lagi !!!";
}
else {
echo "Cuaca hari ini  $cuaca, Ayo ke Mall !!!";
}	
?>
<hr size=5 color="blue">


<?php
$day = date ("D");
switch ($day) {
case 'SUN' : $hari = "Minggu"; break;
case 'Mon' : $hari = "Senin"; break;
case 'Tue' : $hari = "Selasa"; break;
case 'Wed' : $hari = "Rabu"; break;
case 'Thu' : $hari = "Kamis"; break;
case 'Fri' : $hari = "Juma'at"; break;
case 'Sat' : $hari = "Sabtu"; break;
default : $hari = "no day else";
}
echo "Hari ini hari <b>$hari</b> <br>";
?>

<?php
$day = date ("l d F Y");

Echo " Saat ini : " . $day;
?>

</body>
</html>