<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<form action="lima_b.php" method="post">
  <p><strong>RESTORAN SERBA - SERBI </strong></p>
  <p>Nama Barang  :
    <label>
    <select name="barang" id="barang">
      <option>- PILIH PESANAN -</option>
      <option>Mie Ayam</option>
      <option>Jagung Bakar</option>
      <option>Sate Kambing</option>
    </select>
    </label>
    <br />
    Harga	
    <label>
    <select name="harga" id="harga">
      <option>- HARGA -</option>
      <option>5000</option>
      <option>4000</option>
      <option>12000</option>
      <option>20000</option>
    </select>
    </label>
    <br />
    QTY :
      <label>
      <input name="qty" type="text" id="qty" size="4" maxlength="4" />
      </label>
      <br />
    diskon :
    <label>
    <select name="diskon" id="diskon">
      <option>- DISKON -</option>
      <option value="0">0</option>
      <option value="0.05">5%</option>
      <option value="0.1">10%</option>
    </select>
    </label>
    <br />
    <br />
    <input name="submit" type="submit" value="Proses" />
    <label>
    <input type="reset" name="Reset" value="Clear" />
    </label>
</form>
</body>
</html>
