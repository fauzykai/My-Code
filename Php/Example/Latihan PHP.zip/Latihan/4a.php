<HEAD>
<TITLE> Latihan ketiga </TITLE>
</HEAD>
<BODY>
<FORM METHOD="POST" ACTION="4b.php">
Silakan Masukkan Nama Anda <BR>
<INPUT TYPE="text" NAME="nama"><BR>
Silakan Masukkan Pesan Anda <BR>
<TEXTAREA NAME="pesan" ROWS="5" COLS="30"></TEXTAREA><BR>
<INPUT TYPE="submit" value="Kirim">
</FORM>
</BODY>
</HTML>

