<html>
<body>

<?php

$txt="Hello World";
echo $txt;

?>

</body>
</html>
