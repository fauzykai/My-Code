<html>
<head>
	<title> First </title>
</head>
<body>

<?php

//contoh STATEMENT

echo "<h1>hello Guys � ! </h1>";
echo "<font color=blue>Saya dari Script PHP</font>";
echo "<h2>Ini adalah contoh dari penulisan Script PHP</h2>";

?>

</body>
</html>