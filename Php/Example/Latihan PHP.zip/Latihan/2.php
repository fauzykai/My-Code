<html>
<TITLE>Variabel dalam PHP</TITLE>
</HEAD>
<BODY>

<?php
$hobi = "Mancing";
echo "Kegemaran anda adalah $hobi";
?>

</BODY>
</HTML>