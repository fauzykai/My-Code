<html>
<head>

<title>variabel strings</title>
</head>
<body>

	<?php
	
	//membuat variabel string
		$nama="SAFIRA FAUZIYYAH AKBAR";
		$tgl_lahir='09 November 2007';
		$komen= "Jangan pernah menyerah \"Terus Semangat\"";
		
	//menampilkan nilai dari variabel
		echo "Nama Saya : $nama " ;
		echo "<br>Tanggal lahir : $tgl_lahir";
		echo "<br>Komentar : $komen ";
	
	?> 
<hr>	
	
</body>
</html>
