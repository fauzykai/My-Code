<html>
<head><title>Pengolahan Form</title></head>
<body>

	<FORM ACTION="" METHOD="POST" NAME="input">
	Nama Anda : <input type="text" name="nama"><br>
	<input type="submit" name="Input" value="Input">
	<input type="reset" name="hapus" value="Clear">
	</FORM>
</body>
</html>

<?php
if ($_POST['input']) {
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
echo "Nama Anda : <b>$nama</b>";
}
?>
