
<h2>
<Center>
PROGRAM PENJUALAN
<hr>
<table border=2 bgcolor="#CCFFFF">
<tr><td>Nama Barang <td> Komputer
<?
 $harga=1000000;





 
 echo "<tr><td>Harga<td> $harga";
 echo "<tr><td>Jumlah<td> $jumlah";




?>

