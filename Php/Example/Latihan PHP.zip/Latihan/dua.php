<html>
<head>

<title>variabel strings</title>
</head>
<body>

<?php

$jumlahBarang = 3;
$harga = 1000;
$pembayaran = $jumlahBarang * $harga;

echo "<h2> FAKTUR BELANJA </h2>";
echo "<hr>";
echo "QTY beli = $jumlahBarang <br>" ;  
echo "Harga /unit = $harga <br>" ; 
echo "Nilai Yang Harus Dibayar  = $pembayaran " ;   

?>

</body>
</html>
