<HTML>
<HEAD>
<TITLE>Menampilkan Bilangan 1-20</TITLE>
</HEAD>
<BODY>
<?php
  $bilangan = 1;
  while ($bilangan <= 20)
  {
     print("$bilangan <BR>\n");
     $bilangan++;
  }
?>
</BODY>
</HTML>
