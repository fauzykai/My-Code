<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="insert.php">
  <table width="215" border="1">
  <tr>
      <td>No</td>
      <td><label>
        <input type="hidden" name="no" id="no" />
      </label></td>
    </tr>
    <tr>
      <td>Jumlah</td>
      <td><label>
        <input type="text" name="jumlah" id="jumlah" />
      </label></td>
    </tr>
    <tr>
      <td>Nama</td>
      <td><label>
        <input type="text" name="nama" id="nama" />
      </label></td>
    </tr>
    <tr>
      <td>Alamat</td>
      <td><label>
        <input type="text" name="alamat" id="alamat" />
      </label></td>
    </tr>
    <tr>
      <td>Telp</td>
      <td><label>
        <input type="text" name="telp" id="telp" />
      </label></td>
       <tr>
      <td><input type="submit" name="simpan" value="simpan" /></td></tr>
    </tr>
  </table>
</form>
</body>
</html>
