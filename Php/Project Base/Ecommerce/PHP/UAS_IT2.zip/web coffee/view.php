<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<p><a href="index.html">Tambah</a></p>

<form id="form1" name="form1" method="post" action="">
<table border="1">
<tr>
<td>No</td>
<td>Jumlah</td>
<td>Nama</td>
<td>Alamat</td>
<td>Telp</td>
<td>Opsi</td>
</tr>
<?php
include('config.php');
$query=mysql_query("select * from user") or die(mysql_error());
while($data=mysql_fetch_array($query))
{
?>
<tr>
<td><?php echo $data['no'];?></td>
<td><?php echo $data['jumlah'];?></td>
<td><?php echo $data['nama'];?></td>
<td><?php echo $data['alamat'];?></td>
<td><?php echo $data['telp'];?></td>
<td><a href="edit.php?no=<?php echo $data['no'];?>">Edit </a> || <a href="hapus.php?no=<?php echo $data['no'];?>"> Hapus </a></td>
</tr>
<?php
}
?>
</table>

</form>
</body>
</html>
