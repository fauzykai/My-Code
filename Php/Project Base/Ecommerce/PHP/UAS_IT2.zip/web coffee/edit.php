<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
include('config.php');
$id=$_GET['no'];
$query=mysql_query("select *from user where no='$id'")or die(mysql_error());
$data=mysql_fetch_array($query);

?>
<form id="form1" name="form1" method="post" action="update.php">
  <table width="200" border="1">
   <tr>
      <td>No</td>
      <td><label>
        <input type="hidden" name="no" id="no" value="<?php echo $data['no'];?>"/>
      </label></td>
    </tr>
    <tr>
      <td>Jumlah</td>
      <td><label>
        <input type="text" name="jumlah" id="jumlah" value="<?php echo $data['jumlah'];?>"/>
      </label></td>
    </tr>
    <tr>
      <td>Nama</td>
      <td><label>
        <input type="text" name="nama" id="nama" value="<?php echo $data['nama'];?>"/>
      </label></td>
    </tr>
    <tr>
      <td>Alamat</td>
      <td><label>
        <input type="text" name="alamat" id="alamat" value="<?php echo $data['alamat'];?>"/>
      </label></td>
    </tr>
    <tr>
      <td>Telp</td>
      <td><label>
        <input type="text" name="telp" id="telp" value=" <?php echo $data['telp'];?>"/>
      </label></td>
      <tr>
      <td><input type="submit" name="simpan" value="simpan" /></td></tr>
    </tr>
  
  </table>
</form>
</body>
</html>
