<?php
include('config.php');
$id=$_GET['no'];
$query=mysql_query("delete from user where no='$id'");
if($query)
{
echo ("Data berhasil di hapus");
echo ("<a href='view.php'> Lihat Data</a>");
}
else{
echo ("Data gagal di hapus");
echo ("<a href='view.php'> Lihat Data</a>");
}
?>
