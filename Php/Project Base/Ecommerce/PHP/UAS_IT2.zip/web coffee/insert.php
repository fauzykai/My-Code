<?php
include('config.php');
$id=$_POST['no'];
$jumlah=$_POST['jumlah'];
$nama=$_POST['nama'];
$alamat=$_POST['alamat'];
$telp=$_POST['telp'];
$query=mysql_query("insert into user value('no','$jumlah','$nama','$alamat','$telp')") or die(mysql_error());
if($query)
{
echo ("Data berhasil ditambah");
echo ("<a href='view.php'>Lihat Data </a>");
}
else
{
echo ("Data gagal ditambah");
echo ("<a href='tambah.php'> Coba Lagi </a>");
}
?>
