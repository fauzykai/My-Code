<?php
include('config.php');
$id=$_POST['no'];
$jumlah=$_POST['Jumlah'];
$nama=$_POST['nama'];
$alamat=$_POST['alamat'];
$telp=$_POST['telp'];
$query=mysql_query("update user set  jumlah='$jumlah',nama='$nama',alamat='$alamat',telp='$telp' where no='$id'")or die(mysql_error());
if($query)
{
echo ("Data berhasil di update");
echo ("<a href='view.php'> Tampil Data </a>");
}
else
{
echo ("Data gagal di update");
echo ("<a href='view.php'> Tampil data</a>");
}

?>