/*
  pins_arduino.c - pin definitions for the Arduino board
  Part of Arduino / Wiring Lite

  Copyright (c) 2005 David A. Mellis

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

  $Id: pins_arduino.c 963 2010-05-16 04:05:40Z dmellis $
*/

#include <avr/io.h>
#include "wiring_private.h"
#include "pins_arduino.h"

// On the Arduino board, digital pins are also used
// for the analog output (software PWM).  Analog input
// pins are a separate set.

// ATMEL ATMEGA8 & 168 / ARDUINO
//
//                  +-\/-+
//            PC6  1|    |28  PC5 (AI 5)
//      (D 0) PD0  2|    |27  PC4 (AI 4)
//      (D 1) PD1  3|    |26  PC3 (AI 3)
//      (D 2) PD2  4|    |25  PC2 (AI 2)
// PWM+ (D 3) PD3  5|    |24  PC1 (AI 1)
//      (D 4) PD4  6|    |23  PC0 (AI 0)
//            VCC  7|    |22  GND
//            GND  8|    |21  AREF
//            PB6  9|    |20  AVCC
//            PB7 10|    |19  PB5 (D 13)
// PWM+ (D 5) PD5 11|    |18  PB4 (D 12)
// PWM+ (D 6) PD6 12|    |17  PB3 (D 11) PWM
//      (D 7) PD7 13|    |16  PB2 (D 10) PWM
//      (D 8) PB0 14|    |15  PB1 (D 9) PWM
//                  +----+
//
// (PWM+ indicates the additional PWM pins on the ATmega168.)

// ATMEL ATMEGA1280 / ARDUINO
//
// 0-7 PE0-PE7   works
// 8-13 PB0-PB5  works
// 14-21 PA0-PA7 works 
// 22-29 PH0-PH7 works
// 30-35 PG5-PG0 works
// 36-43 PC7-PC0 works
// 44-51 PJ7-PJ0 works
// 52-59 PL7-PL0 works
// 60-67 PD7-PD0 works
// A0-A7 PF0-PF7
// A8-A15 PK0-PK7

//*	atmega32 defines PE as a bit in the UCSRA register
#undef PE

#define PA 1
#define PB 2
#define PC 3
#define PD 4
#define PE 5
#define PF 6
#define PG 7
#define PH 8
#define PJ 10
#define PK 11
#define PL 12

#if defined(__AVR_ATmega128__)
	//*	pin defs for SOC-Amber128 web serverboard
	#include	"pins_amber128.cxx"

#elif defined(__AVR_ATtiny45__ )
	//*	pin defs for Avr attin45
	#include	"pins_attiny45.cxx"

#elif defined(__AVR_ATtiny2313__ )
	//*	pin defs for Avr attin45
	#include	"pins_attiny2313.cxx"

#elif defined(__AVR_ATmega169__)
	//*	pin defs for Avr Butterfly
	#include	"pins_butterfly.cxx"

#elif defined(__AVR_ATmega32__)
	// Penguino	www.icy.com.au
	//*	pin defs for Penguino AVR board
	#include	"pins_penguino_avr.cxx"

#elif defined(__AVR_ATmega324P__) // GATOR
	//*	pin defs for GatorPlus board
	#include	"pins_gatorplus.cxx"

#elif defined(__AVR_ATmega644__) || defined(__AVR_ATmega644P__)
	//*	pin defs for duino644 and sanquino board
	#include	"pins_duino644.cxx"

#elif defined(__AVR_ATmega645__)
	//*	pin defs for Liquidware Illuminato board
	#include	"pins_illuminato.cxx"

#elif defined(__AVR_ATmega1281__)
	//*	pin defs for Wiring1281 board
	#include	"pins_wiring1281.cxx"

#elif defined(__AVR_ATmega2560__) && (F_CPU == 8000000L)
	//*	pin defs for Cerebot 2560 board
	#include	"pins_cerebotplus.cxx"

#elif defined(__AVR_ATmega2561__)
	//*	pin defs for http://www.bostonandroid.com/EVAL-USB-2561.html
	#include	"pins_android2561.cxx"

#elif defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__)
	//*	Arduino mega board
	#include	"pins_mega.cxx"

#elif defined(__AVR_ATmega32U4__)
	#include	"pins_teensy2.cxx"

#elif defined(__AVR_ATmega168__) || defined(__AVR_ATmega328P__) || defined(__AVR_ATmega8__) || defined(__AVR_ATmega88__)

	#include	"pins_duemilanove.cxx"

#else
	//*	this file does its best to figure out which pins are enabled
	#include	"pins_unknown.cxx"

#endif
